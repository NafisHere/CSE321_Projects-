#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_USERS 10 // minimum ro duita nite bolse ami 10 ta nisi as ro barte pare
#define MAX_RESOURCES 10
#define MAX_NAME_LEN 20

typedef enum {
READ = 1,
WRITE = 2,
EXECUTE = 4
} Permission;

typedef struct {
char name[MAX_NAME_LEN];
} User;

typedef struct {
char name[MAX_NAME_LEN];
} Resource;


typedef struct {
char username[MAX_NAME_LEN];
int permissions;
} ACLEntry;

typedef struct {
Resource resource;
ACLEntry aclEntries[MAX_USERS];
int aclCount;
} ACLControlledResource;

typedef struct {
char resourceName[MAX_NAME_LEN];
int permissions;
} Capability;

typedef struct {
User user;
Capability capabilities[MAX_RESOURCES];
int capabilityCount;
} CapabilityUser;
void printPermissions(int perm) {
if (perm & READ) printf("Read ");
if (perm & WRITE) printf("Write ");
if (perm & EXECUTE) printf("Execute ");}

int hasPermission(int userPerm, int requiredPerm) {
return (userPerm & requiredPerm) == requiredPerm;}
void checkACLAccess(ACLControlledResource *res, const char *userName, int perm) {
for (int i = 0; i < res->aclCount; i++) {
if (strcmp(res->aclEntries[i].username, userName) == 0) {
	if (hasPermission(res->aclEntries[i].permissions, perm)) {
    	printf("ACL Check: User %s requests ", userName);
    	printPermissions(perm);
    	printf("on %s: Access GRANTED\n", res->resource.name);
    	return;
	} else {
    	printf("ACL Check: User %s requests ", userName);
    	printPermissions(perm);
    	printf("on %s: Access DENIED\n", res->resource.name);
    	return;
	}}}
printf("ACL Check: User %s has NO entry for resource %s: Access DENIED\n", userName, res->resource.name);}

void checkCapabilityAccess(CapabilityUser *user, const char *resourceName, int perm) {
for (int i = 0; i < user->capabilityCount; i++) {
if (strcmp(user->capabilities[i].resourceName, resourceName) == 0) {
	if (hasPermission(user->capabilities[i].permissions, perm)) {
    	printf("Capability Check: User %s requests ", user->user.name);
    	printPermissions(perm);
    	printf("on %s: Access GRANTED\n", resourceName);
    	return;
	} else {
    	printf("Capability Check: User %s requests ", user->user.name);
    	printPermissions(perm);
    	printf("on %s: Access DENIED\n", resourceName);
    	return;
	}}}
printf("Capability Check: User %s has NO capability for resource %s: Access DENIED\n", user->user.name, resourceName);}

void addACLEntry(ACLControlledResource *res, const char *username, int permissions) {
strcpy(res->aclEntries[res->aclCount].username, username);
res->aclEntries[res->aclCount].permissions = permissions;
res->aclCount++;}

void addCapability(CapabilityUser *user, const char *resourceName, int permissions) {
strcpy(user->capabilities[user->capabilityCount].resourceName, resourceName);
user->capabilities[user->capabilityCount].permissions = permissions;
user->capabilityCount++;}

int main() {
User users[] = {{"Alice"}, {"Bob"}, {"Charlie"}, {"Dave"}, {"Eve"}};
int userCount = 5;
Resource resources[] = {{"File1"}, {"File2"}, {"File3"}, {"File4"}, {"File5"}};
int resourceCount = 5;
ACLControlledResource aclResources[5];
for (int i = 0; i < resourceCount; i++) {
aclResources[i].resource = resources[i];
aclResources[i].aclCount = 0;}
addACLEntry(&aclResources[0], "Alice", READ | WRITE);
addACLEntry(&aclResources[0], "Bob", READ);
addACLEntry(&aclResources[1], "Charlie", READ | EXECUTE);
addACLEntry(&aclResources[3], "Dave", WRITE);
addACLEntry(&aclResources[4], "Eve", READ | EXECUTE);
CapabilityUser capUsers[5];
for (int i = 0; i < userCount; i++) {
capUsers[i].user = users[i];
capUsers[i].capabilityCount = 0;}
addCapability(&capUsers[0], "File1", READ | WRITE);
addCapability(&capUsers[1], "File1", READ);
addCapability(&capUsers[2], "File2", READ);
addCapability(&capUsers[3], "File4", WRITE);
addCapability(&capUsers[4], "File5", EXECUTE);
checkACLAccess(&aclResources[0], "Alice", READ);
checkACLAccess(&aclResources[0], "Bob", WRITE);
checkACLAccess(&aclResources[0], "Charlie", EXECUTE);
checkACLAccess(&aclResources[3], "Dave", WRITE);
checkACLAccess(&aclResources[4], "Eve", EXECUTE);
checkACLAccess(&aclResources[4], "Charlie", READ);
checkCapabilityAccess(&capUsers[0], "File1", WRITE);
checkCapabilityAccess(&capUsers[1], "File1", WRITE);
checkCapabilityAccess(&capUsers[2], "File2", EXECUTE);
checkCapabilityAccess(&capUsers[3], "File4", WRITE);
checkCapabilityAccess(&capUsers[4], "File5", EXECUTE);
checkCapabilityAccess(&capUsers[2], "File5", READ);
return 0;}
