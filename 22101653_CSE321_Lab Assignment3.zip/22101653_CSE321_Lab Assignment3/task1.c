#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
struct shared_memory{
char operation[100];
int current_balance;
};

int main() {

key_t mem_key = 1010;
int mem_id = shmget(mem_key, 1024, 0666 | IPC_CREAT);//shared memory create korchiii
struct shared_memory *mem_ptr = (struct shared_memory *)shmat(mem_id, NULL, 0);//shared memory attach

int comm_pipe[2];
pipe(comm_pipe);//pipe create korlam

printf("Provide Your Input From Given Options:\n");
printf("1. Type a to Add Money\n");
printf("2. Type w to Withdraw Money\n");
printf("3. Type c to Check Balance\n");

scanf("%s", mem_ptr->operation); //user input nitesii
mem_ptr->current_balance = 1000; //initial balance set
printf("Your selection: %s\n\n", mem_ptr->operation);

pid_t trx_process = fork();//child process create korlam 

if (trx_process == 0){
int input_amount;
if (strcmp(mem_ptr->operation, "a") == 0){
    printf("Enter amount to be added:\n");
    scanf("%d", &input_amount);

    if (input_amount > 0){
        mem_ptr->current_balance += input_amount;//balance add kortesi
        printf("Balance added successfully\n");
        printf("Updated balance after addition:\n%d\n", mem_ptr->current_balance);
    } else{
        printf("Adding failed, Invalid amount\n");}
} else if (strcmp(mem_ptr->operation, "w") == 0){
    printf("Enter amount to be withdrawn:\n");
    scanf("%d", &input_amount);

    if (input_amount > 0 && input_amount <= mem_ptr->current_balance) {
        mem_ptr->current_balance -= input_amount; //balancetheke amount minuus kortesi
        printf("Balance withdrawn successfully\n");
        printf("Updated balance after withdrawal:\n%d\n", mem_ptr->current_balance);
    }else{
        printf("Withdrawal failed, Invalid amount\n");}
        
}else if (strcmp(mem_ptr->operation, "c") == 0){
    printf("Your current balance is:\n%d\n", mem_ptr->current_balance); //balance show
}else{
    printf("Invalid selection\n");}

char closing_msg[200] = "Thank you for using ";
write(comm_pipe[1], closing_msg, sizeof(closing_msg)); //pipe diye parent ke message pathacchi

shmdt((void *)mem_ptr); //shared memory detach
}else{
wait(NULL); //     child process complete howar jonne waitt...

char msg_buffer[200];
read(comm_pipe[0], msg_buffer, sizeof(msg_buffer));//child theke message read 
printf("%s\n", msg_buffer);


shmdt((void *)mem_ptr); //shared memory detach
shmctl(mem_id, IPC_RMID, NULL);} //create kora shared mem del korlam

return 0;}

