#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <sys/wait.h>

struct message{
long int type;
char text[6];};

int main(){

key_t mq_key = 1010;
int mq_id = msgget(mq_key, 0666 | IPC_CREAT);// msg queue create korchii
printf("Please enter the workspace name:\n");
char ws_name[6];
scanf("%s", ws_name);// user input nicchi

if (strcmp(ws_name, "cse321") != 0){ // valid workspace check
printf("Invalid workspace name\n");
msgctl(mq_id, IPC_RMID, NULL);//msg queue delete
return 0;}

struct message msg_buffer;
strcpy(msg_buffer.text, ws_name);
msg_buffer.type = 1;
printf("Workspace name sent to otp generator from Log In: %s\n\n", ws_name);
msgsnd(mq_id, &msg_buffer, sizeof(msg_buffer.text), 0);//workspace name send korchi otp genertor kee
pid_t otp_pid = fork();//otp generator process create korchi

if (otp_pid == 0){
msgrcv(mq_id, &msg_buffer, sizeof(msg_buffer.text), 1, 0);//workspace name recieve kortesee
printf("OTP generator received workspace name from log in: %s\n\n", msg_buffer.text);
char generated_otp[6];

sprintf(generated_otp, "%d", getpid());//otp generate kortese using process id
strcpy(msg_buffer.text, generated_otp);
msg_buffer.type = 2;
msgsnd(mq_id, &msg_buffer, sizeof(msg_buffer.text), 0);//otp pathacchi login k
printf("OTP sent to log in from OTP generator: %s\n", generated_otp);
msg_buffer.type = 3;
msgsnd(mq_id, &msg_buffer, sizeof(msg_buffer.text), 0);//otp pathchhi mail prcess k
printf("OTP sent to mail from OTP generator: %s\n", generated_otp);
pid_t mail_pid = fork();//mail process create kortsi

if (mail_pid == 0){
    msgrcv(mq_id, &msg_buffer, sizeof(msg_buffer.text), 3, 0);//otp recv kortese otp gen theke
    printf("Mail received OTP from OTP generator: %s\n", msg_buffer.text);
    
    msg_buffer.type = 4;
    msgsnd(mq_id, &msg_buffer, sizeof(msg_buffer.text), 0);//otp pathacchi login k
    printf("OTP sent to log in from mail: %s\n", msg_buffer.text);
    return 0;}
    
    
wait(NULL);//mail pro wait

return 0;}

wait(NULL);//login procss wait 
msgrcv(mq_id, &msg_buffer, sizeof(msg_buffer.text), 2, 0);//otp recv kortese otp gen theke
printf("Log in received OTP from OTP generator: %s\n", msg_buffer.text);
char otp_direct[6];
strncpy(otp_direct, msg_buffer.text, 6);
msgrcv(mq_id, &msg_buffer, sizeof(msg_buffer.text), 4, 0);//rcv otp from mail
printf("Log in received OTP from mail: %s\n", msg_buffer.text);
char otp_from_mail[6];
strncpy(otp_from_mail, msg_buffer.text, 6);

if (strcmp(otp_direct, otp_from_mail) == 0){// duita otp match??
printf("OTP Verified\n");

}else{

printf("OTP Incorrect\n");}
msgctl(mq_id, IPC_RMID, NULL);//msg que delete
return 0;}

