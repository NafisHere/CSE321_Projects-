#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

//febo data structure

typedef struct {
int n; // fin seq er last term
int* fib_sequence; /// Fibonacci sequence store korar array
} FibData;

typedef struct {
int* fib_sequence; // Fibonacci sequence er pointer
int fib_length;	// Fibonacci sequence er length
int num_searches;   // Koyta number search korte hobe
int* search_indices; // Search korar index
int* search_results;  // Search result
} SearchData;

//thread 1 for generatingg fibo series
void* generate_fibonacci(void* arg) {
	FibData* data = (FibData*)arg;
    
	//user input fin seq er jonne
	printf("Enter the term of fibonacci sequence:\n");
	scanf("%d", &data->n);

	//memory allocate korbo fib seq store korar jonne
	data->fib_sequence = (int*)malloc((data->n + 1) * sizeof(int));
	if (data->fib_sequence == NULL) {
    	perror("Memory allocation failed for Fibonacci sequence");
    	pthread_exit(NULL);
	}
	//first 2 term set korbo
	data->fib_sequence[0] = 0;
	if (data->n >= 1) data->fib_sequence[1] = 1;
	//rest terms calc
	for (int i = 2; i <= data->n; ++i) {
    	data->fib_sequence[i] = data->fib_sequence[i - 1] + data->fib_sequence[i - 2];
	}
	//fib seq print
	for (int i = 0; i <= data->n; ++i) {
    	printf("a[%d] = %d\n", i, data->fib_sequence[i]);
	}

	pthread_exit(NULL);
}
//thread 2 for search fibonacci series
void* search_fibonacci(void* arg) {
	SearchData* data = (SearchData*)arg;
    
	//user input for koita input number search korbe
	printf("How many numbers you are willing to search?:\n");
	scanf("%d", &data->num_searches);
    
	//memory allocate for search indices and res
	data->search_indices = (int*)malloc(data->num_searches * sizeof(int));
	data->search_results = (int*)malloc(data->num_searches * sizeof(int));
	if (data->search_indices == NULL || data->search_results == NULL) {
    	perror("Memory allocation failed for search data");
    	pthread_exit(NULL);
	}
 	//search indices input nibo from user
	for (int i = 0; i < data->num_searches; ++i) {
    	printf("Enter search %d:\n", i + 1);
    	scanf("%d", &data->search_indices[i]);
	}
	//search and sotre res
	for (int i = 0; i < data->num_searches; ++i) {
    	if (data->search_indices[i] >= 0 && data->search_indices[i] <= data->fib_length) {
        	data->search_results[i] = data->fib_sequence[data->search_indices[i]];
    	} else {
        	data->search_results[i] = -1; //invalid idx er jonne -1
    	}
	}
	//search res print
	for (int i = 0; i < data->num_searches; ++i) {
    	printf("result of search #%d = %d\n", i + 1, data->search_results[i]);
	}
    
	pthread_exit(NULL);
}

int main() {
	pthread_t t1, t2; //thrd id
	FibData fib_data;  //uporer DS gula
	SearchData search_data;

	//First thread create  for feb seq generation
	pthread_create(&t1, NULL, generate_fibonacci, &fib_data);
	pthread_join(t1, NULL);

	//search data set up
	search_data.fib_sequence = fib_data.fib_sequence;
	search_data.fib_length = fib_data.n;

	//Second thread create for searching
	pthread_create(&t2, NULL, search_fibonacci, &search_data);
	pthread_join(t2, NULL);

	//Free allocated memory nahole leak korbe
	free(fib_data.fib_sequence);
	free(search_data.search_indices);
	free(search_data.search_results);
	return 0;
}
