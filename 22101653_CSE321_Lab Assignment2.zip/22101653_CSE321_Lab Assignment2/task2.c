#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

//global vars

#define NUM_STUDENTS 10  // no of students 10(as per qstn)
#define NUM_CHAIRS 3  // no of chair 3 ta

sem_t waiting_students; //waiting students sem
sem_t st_ready; 	//ready sem
sem_t consultation_done;
pthread_mutex_t chair_mutex;

int waiting_chairs = 0; //track to see koita chair occupied
int served_students = 0; // --  --   --	---  koijon k serve kora hoyeche

//func prototype declare

void* tutor(void* arg);
void* student(void* arg);

int main() {
	pthread_t tutor_thread;
	pthread_t student_threads[NUM_STUDENTS];
    
	//semaphore init
	sem_init(&waiting_students, 0, 0);
	sem_init(&st_ready, 0, 0);
	sem_init(&consultation_done, 0, 0);
	pthread_mutex_init(&chair_mutex, NULL);
    
	//create tutor thread
	pthread_create(&tutor_thread, NULL, tutor, NULL);
    
	//create student thread
	for (int i = 0; i < NUM_STUDENTS; i++) {
    	int* id = malloc(sizeof(int));
    	*id = i;
    	sleep(rand() % 3); //random delay
    	pthread_create(&student_threads[i], NULL, student, id);
	}
	//waits until threads are completed
	for (int i = 0; i < NUM_STUDENTS; i++) {
    	pthread_join(student_threads[i], NULL);
	}
	//semaphore destroy to clean
	pthread_join(tutor_thread, NULL);
	sem_destroy(&waiting_students);
	sem_destroy(&st_ready);
	sem_destroy(&consultation_done);
	pthread_mutex_destroy(&chair_mutex);
	printf("All students have been served....!!\n");
	return 0;}

void* tutor(void* arg) {
	//untill all students k cons dewa hoi
	while (served_students < NUM_STUDENTS) {
    
	//waiting for students who are waiting
    	sem_wait(&waiting_students);
   	 
    	//chair count update
    	pthread_mutex_lock(&chair_mutex);
    	waiting_chairs--;
    	printf("A waiting student started getting Consultation\n");
    	printf("Number of students now waiting: %d\n", waiting_chairs);
    	pthread_mutex_unlock(&chair_mutex);

    	printf("ST giving Consultation\n");
   	 
    	//notify students that st is giving cons
    	sem_post(&st_ready);
   	 
    	//wait untill cons ends
    	sem_wait(&consultation_done);
	}

	return NULL;
}

void* student(void* arg) {
	int id = *(int*)arg;
	printf("Student %d started waiting for consultation\n", id);
    
	//to sit for cons
	pthread_mutex_lock(&chair_mutex);
    
	if (waiting_chairs < NUM_CHAIRS) {
    	waiting_chairs++;
    	pthread_mutex_unlock(&chair_mutex);
   	 
    	//inform st je ekjon student wait korche
    	sem_post(&waiting_students);
   	 
    	//wait until st ready for cons
    	sem_wait(&st_ready); 	 
    	printf("Student %d is getting consultation\n", id);
    	sleep(1); //consultationn time
    	printf("Student %d finished getting consultation and left\n", id);

    	//totoal served students count
    	pthread_mutex_lock(&chair_mutex);
    	served_students++;
    	printf("Number of served students: %d\n", served_students);
    	pthread_mutex_unlock(&chair_mutex);
   	 
    	// notify tutor that consultation sesh
    	sem_post(&consultation_done);
	} else {
    
    	//chair er theke beshi students ashle leave korbe
    	printf("No chairs remaining in lobby. Student %d leaving...\n", id);
    	pthread_mutex_unlock(&chair_mutex);}
	free(arg);
	return NULL;}
