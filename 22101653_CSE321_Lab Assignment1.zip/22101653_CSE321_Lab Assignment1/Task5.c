#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main()
{
	pid_t pid = fork();
	if (pid == 0) 
	{
    	printf("2. Child process ID: %d\n", getpid()); //child process
    	pid_t gchild1 = fork();
    	if (gchild1 == 0){ //grand child 1
        	printf("3. Grand Child process ID: %d\n", getpid());
        	exit(0);}
    	pid_t gchild2 = fork();
    	if (gchild2 == 0){ //grand child 2
        	printf("4. Grand Child process ID: %d\n", getpid());
        	exit(0);}
    	pid_t gchild3 = fork();
    	if (gchild3 == 0){ //grand child 3
        	printf("5. Grand Child process ID: %d\n", getpid());
        	exit(0);}}
	else{ //parent proecess
    	printf("1. Parent process ID: %d\n", getpid());
	}
	return 0;
}

