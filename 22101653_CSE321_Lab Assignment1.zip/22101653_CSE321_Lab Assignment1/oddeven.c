#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void checkOddEven(int numbers[], int length) {
    printf("Odd or Even Check:\n");
    for (int i = 0; i < length; i++) {
        if (numbers[i] % 2 != 0) { //if odd
            printf("%d is Odd\n", numbers[i]);
        } else { //even
            printf("%d is Even\n", numbers[i]);
        }}}

int main(int argumentCount, char *argumentValues[]) {
    int numberCount = argumentCount-1;
    int inputNumbers[numberCount];

    for (int i = 1; i < argumentCount; i++) {
        inputNumbers[i - 1] = atoi(argumentValues[i]);  // used atoi to Convert string to integer
    }
    checkOddEven(inputNumbers, numberCount);

    return 0;}
