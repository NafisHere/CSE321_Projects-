#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/wait.h>

int main() {
    //create shared memory for count nmbr of processes
    int *processCount = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);

    if (processCount == MAP_FAILED) {
        printf("M map failed\n");
        return 1;
    }
    *processCount = 1; //count main parent 

    pid_t forkA, forkB, forkC, currentProcessID;
    pid_t originalParentPID = getpid(); // Main parent PID

    forkA = fork();
    if (forkA == 0) {
        (*processCount)++;
    }

    forkB = fork();
    if (forkB == 0) {
        (*processCount)++;
    }

    forkC = fork();
    if (forkC == 0) {
        (*processCount)++;
    }

    currentProcessID = getpid();

    if (currentProcessID % 2 != 0) { // Checks if odd PID?
        pid_t additionalChild = fork();

        if (additionalChild == 0) {
            (*processCount)++;
        } else {
            wait(NULL); // Parent waits for child
        }
    }

    // Only original parent process prints the final result
    if (getpid() == originalParentPID) {
        sleep(2); // Wait for all forks to complete
        printf("Total number of processes: %d\n", *processCount);
        munmap(processCount, sizeof(int));
    }

    return 0;
}

