#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void sortDescending(int numbers[], int length){
    for (int i = 1; i < length; i++) {
        int current = numbers[i];
        int position = i-1;
        while (position >= 0 && current > numbers[position]){
            numbers[position + 1]=numbers[position];
            position--;}
        numbers[position + 1] = current;}

    printf("Sorted array in descending order:\n");
    for (int i = 0; i < length; i++) {
        printf("%d ", numbers[i]);
    }
    printf("\n\n");
}
int main(int argumentCount, char *argumentValues[]) {
    int arrayLength = argumentCount - 1;
    int inputNumbers[arrayLength];

    for (int i = 1; i < argumentCount; i++) {
        inputNumbers[i - 1] = atoi(argumentValues[i]);  // use atoi for Converting string to integer ((ascii to int))
    }
    sortDescending(inputNumbers, arrayLength);

    return 0;
}
