#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
	pid_t child_pid, grandchild_pid;

	// Create child prcss
	child_pid = fork();
	if (child_pid < 0){
    	perror("Failed to create child process");
    	exit(1);
	}
	else if (child_pid == 0){
    	//Inside child process  -----> grandchild
    	grandchild_pid = fork();

    	if (grandchild_pid < 0) {
        	perror("Failed to create grandchild process");
        	exit(1);
    	}
    	else if (grandchild_pid == 0) {
        	//Inside grandchild process
        	printf("I am grandchild (PID: %d)\n", getpid());
        	exit(0);
    	}
    	else {
        	//Child waits for grandchild
        	wait(NULL);
        	printf("I am child (PID: %d)\n", getpid());
        	exit(0);
    	}
	}
	else {
    	// Parent waits for child
    	wait(NULL);
    	printf("I am parent (PID: %d)\n", getpid());
	}

	return 0;
}
