#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argumentCount, char *argumentValues[]){
	FILE *outputFile;
	char userInput[100];
    
	//checks if filename was provided?
	if (argumentCount<2){
    	printf("How to Use?: %s <<filename>>\n", argumentValues[0]);
    	return 1;
	}
	outputFile = fopen(argumentValues[1], "a"); //open or create
	if (outputFile == NULL) {
    	printf("Error Could not open file for writing\n");
    	return 1;
	}
	printf("Enter strings to write to file (enter \"-1\" to finish):\n");

	while (1) {
    	printf("PLease Enter Strings: ");
    	if (fgets(userInput, sizeof(userInput), stdin) == NULL) {
        	printf("Error reading user input.\n");
        	break;}
        userInput[strcspn(userInput, "\n")] = '\0';
   	 
    	//check if -1 terminata--
    	if (strcmp(userInput, "-1") == 0) {
        	break;
    	}
   	 
    	// Write
    	fprintf(outputFile, "%s\n", userInput);
	}
	fclose(outputFile);
	printf("All text has been saved to %s.\n", argumentValues[1]);
	return 0;
}
